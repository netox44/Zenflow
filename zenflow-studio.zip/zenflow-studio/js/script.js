/* ===== ZENFLOW STUDIO — script ===== */
(function () {
  'use strict';
  const CUR = '$'; // change to 'Rs. ' for rupees
  const U = (id, w = 900) => `https://images.unsplash.com/photo-${id}?auto=format&fit=crop&w=${w}&q=80`;

  /* image fallback */
  const FB = 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 500"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#cfd3b0"/><stop offset="1" stop-color="#7a7330"/></linearGradient></defs><rect width="400" height="500" fill="url(#g)"/><text x="200" y="258" text-anchor="middle" font-family="Arial,sans-serif" font-size="30" letter-spacing="4" fill="#fff">ZENFLOW</text></svg>');
  document.addEventListener('error', (e) => { const t = e.target; if (t.tagName === 'IMG' && !t.dataset.fb) { t.dataset.fb = 1; t.src = FB; } }, true);

  /* icons */
  const P = {
    leaf: '<path d="M5 19c0-9 6-14 15-14 0 9-5 15-14 15"/><path d="M5 19c3-5 6-8 10-10"/>',
    pin: '<path d="M12 21s7-6 7-11a7 7 0 0 0-14 0c0 5 7 11 7 11z"/><circle cx="12" cy="10" r="2.5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
    phone: '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A15 15 0 0 1 3 6a2 2 0 0 1 2-2z"/>',
    check: '<path d="m5 12 5 5 9-10"/>',
    arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
    close: '<path d="M6 6l12 12M18 6 6 18"/>',
    menu: '<path d="M4 8h16M4 16h16"/>',
    insta: '<rect x="4" y="4" width="16" height="16" rx="5"/><circle cx="12" cy="12" r="3.6"/>'
  };
  const ic = (n) => `<span class="i" aria-hidden="true"><svg viewBox="0 0 24 24">${P[n] || ''}</svg></span>`;

  /* data */
  const T = [
    { n: 'Anaya Sharma', r: 'Vinyasa & breathwork', img: '1544005313-94ddf0286df2' },
    { n: 'Daniel Reyes', r: 'Ashtanga & power flow', img: '1500648767791-00dcc994a43e' },
    { n: 'Mira Chen', r: 'Yin yoga & meditation', img: '1534528741775-53994a69daeb' },
    { n: 'Omar Hassan', r: 'Hatha & mobility', img: '1506794778202-cad84cf45f1d' }
  ];
  // d = days (0 = Sunday)
  const C = [
    { n: 'Sunrise Vinyasa', t: '06:30', m: 60, who: 0, lvl: 'All levels', spots: 6, d: [1, 2, 3, 4, 5, 6] },
    { n: 'Gentle Hatha', t: '09:00', m: 60, who: 3, lvl: 'Beginner', spots: 9, d: [1, 3, 5, 0] },
    { n: 'Prenatal Flow', t: '10:30', m: 50, who: 0, lvl: 'Beginner', spots: 4, d: [2, 4, 6] },
    { n: 'Power Ashtanga', t: '12:15', m: 75, who: 1, lvl: 'Advanced', spots: 0, d: [1, 2, 4, 5] },
    { n: 'Mobility Reset', t: '17:30', m: 45, who: 3, lvl: 'All levels', spots: 11, d: [1, 3, 5] },
    { n: 'Yin & Restore', t: '18:45', m: 75, who: 2, lvl: 'All levels', spots: 7, d: [1, 2, 3, 4, 0] },
    { n: 'Breath & Meditation', t: '20:00', m: 40, who: 2, lvl: 'Beginner', spots: 14, d: [2, 4, 6, 0] }
  ];
  const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const PLANS = [
    { n: 'Flow', m: 39, d: 'Four classes every month. A calm start.', f: ['4 classes per month', 'Online library access', 'Mat and prop hire included'] },
    { n: 'Unlimited', m: 89, hot: 1, d: 'Every class, whenever you need it.', f: ['Unlimited studio classes', 'Online library access', 'Bring a friend twice a month', 'Priority booking'] },
    { n: 'Retreat', m: 149, d: 'For a deeper, guided practice.', f: ['Everything in Unlimited', 'Monthly 1:1 private session', 'Weekend workshops included', '10% off retail and retreats'] }
  ];
  const time12 = (t) => { const [h, m] = t.split(':').map(Number); return `${((h + 11) % 12) + 1}:${String(m).padStart(2, '0')} ${h < 12 ? 'AM' : 'PM'}`; };
  const classesOn = (d) => C.filter((c) => c.d.includes(d)).sort((a, b) => a.t.localeCompare(b.t));

  /* layout */
  const page = document.body.dataset.page;
  const nav = [['index.html', 'Home', 'home'], ['classes.html', 'Classes', 'classes'], ['pricing.html', 'Pricing', 'pricing'], ['about.html', 'About', 'about'], ['contact.html', 'Contact', 'contact']];
  function layout() {
    document.body.insertAdjacentHTML('afterbegin', `
      <header class="hdr"><div class="wrap hdr-in">
        <a class="logo" href="index.html"><b>${ic('leaf')}</b>ZENFLOW</a>
        <nav class="pill" id="pill" aria-label="Main">${nav.map((n) => `<a href="${n[0]}" class="${n[2] === page ? 'on' : ''}">${n[1]}</a>`).join('')}</nav>
        <div class="hdr-r"><a class="btn btn-dark" href="classes.html">Book a class</a><button class="burger" id="burger" aria-label="Menu" aria-expanded="false">${ic('menu')}</button></div>
      </div></header>`);
    document.body.insertAdjacentHTML('beforeend', `
      <footer class="ftr"><div class="wrap">
        <div class="ftr-g">
          <div><a class="logo" href="index.html"><b>${ic('leaf')}</b>ZENFLOW STUDIO</a><p style="max-width:24em">A modern yoga and wellness studio with calming spaces, expert teachers and classes for every body.</p></div>
          <div><h4>Studio</h4><ul><li><a href="classes.html">Class schedule</a></li><li><a href="pricing.html">Memberships</a></li><li><a href="about.html">Our teachers</a></li></ul></div>
          <div><h4>Visit</h4><ul><li>24 Willow Lane, Karachi</li><li>Mon–Sat 6am – 9pm</li><li>Sun 8am – 6pm</li></ul></div>
          <div><h4>Contact</h4><ul><li><a href="contact.html">hello@zenflow.studio</a></li><li>+92 300 000 0000</li><li><a href="contact.html">Send a message</a></li></ul></div>
        </div>
        <div class="ftr-b"><span>© ${new Date().getFullYear()} Zenflow Studio. All rights reserved.</span><span>Breathe in. Move on.</span></div>
        <div class="mark" aria-hidden="true">ZENFLOW</div>
      </div></footer>
      <div class="ov" id="ov"><div class="modal" role="dialog" aria-modal="true" aria-labelledby="mt">
        <button class="x" id="mx" aria-label="Close">${ic('close')}</button>
        <h3 id="mt">Reserve your spot</h3><p id="ms" style="color:var(--mut)"></p>
        <form class="form" id="bf" style="border:0;padding:0;background:none" novalidate>
          <label for="bn">Full name</label><input id="bn" required placeholder="Your name">
          <label for="be">Email</label><input id="be" type="email" required placeholder="you@example.com">
          <button class="btn btn-dark" type="submit" style="width:100%;justify-content:center">Confirm booking</button>
        </form></div></div>
      <div class="toast" id="toast" role="status"></div>`);
    document.querySelectorAll('[data-u]').forEach((im) => { im.src = U(im.dataset.u, im.dataset.w || 900); });
    document.querySelectorAll('[data-i]').forEach((el) => { el.innerHTML = ic(el.dataset.i); });
  }

  let tt;
  const toast = (m) => { const t = document.getElementById('toast'); t.textContent = m; t.classList.add('on'); clearTimeout(tt); tt = setTimeout(() => t.classList.remove('on'), 2800); };

  /* rows */
  const row = (c) => `<div class="row-c">
    <div class="t">${time12(c.t)}</div>
    <div><h3>${c.n}</h3><small>with ${T[c.who].n}</small></div>
    <div class="lvl">${c.lvl}</div><div class="dur">${c.m} min</div>
    <div class="spots ${c.spots ? '' : 'full'}">${c.spots ? c.spots + ' spots left' : 'Class full'}</div>
    <button class="btn btn-dark btn-sm" data-book="${c.n}|${time12(c.t)}">${c.spots ? 'Book' : 'Join waitlist'}</button></div>`;

  function team(el) { el.innerHTML = T.map((t) => `<div class="tm"><img src="${U(t.img, 700)}" alt="${t.n}" loading="lazy"><h3>${t.n}</h3><p>${t.r}</p></div>`).join(''); }

  function initHome() {
    const td = document.getElementById('today');
    if (td) {
      const d = new Date().getDay();
      document.getElementById('todayName').textContent = DAYS[d];
      td.innerHTML = classesOn(d).slice(0, 4).map(row).join('') || '<p style="padding:2rem 0">No classes today. See the full schedule.</p>';
    }
    const cd = document.getElementById('countdown');
    if (cd) {
      const tick = () => {
        const now = new Date(), end = new Date(now.getFullYear(), now.getMonth() + 1, 1);
        const s = Math.max(0, end - now) / 1000;
        cd.textContent = `${Math.floor(s / 86400)}d ${Math.floor(s % 86400 / 3600)}h ${Math.floor(s % 3600 / 60)}m`;
      };
      tick(); setInterval(tick, 30000);
    }
  }

  function initClasses() {
    const list = document.getElementById('list');
    if (!list) return;
    let day = new Date().getDay(), lvl = 'All';
    const dbox = document.getElementById('days');
    const draw = () => {
      dbox.innerHTML = [1, 2, 3, 4, 5, 6, 0].map((d) => `<button class="day ${d === day ? 'on' : ''}" data-day="${d}">${DAYS[d].slice(0, 3)}</button>`).join('');
      const items = classesOn(day).filter((c) => lvl === 'All' || c.lvl === lvl);
      list.innerHTML = items.length ? items.map(row).join('') : '<p style="padding:2.5rem 0;color:var(--mut)">No classes match. Try another day or level.</p>';
    };
    dbox.addEventListener('click', (e) => { const b = e.target.closest('[data-day]'); if (b) { day = +b.dataset.day; draw(); } });
    document.getElementById('lvl').addEventListener('change', (e) => { lvl = e.target.value; draw(); });
    draw();
  }

  function initPricing() {
    const box = document.getElementById('plans');
    if (!box) return;
    let yearly = false;
    const draw = () => {
      box.innerHTML = PLANS.map((p) => `<div class="plan ${p.hot ? 'hot' : ''}"><h3>${p.n}</h3><div class="pr">${CUR}${yearly ? Math.round(p.m * 0.8) : p.m}<small> /month</small></div><p>${p.d}</p>
        <ul>${p.f.map((f) => `<li>${ic('check')}${f}</li>`).join('')}</ul>
        <a class="btn ${p.hot ? 'btn-light' : 'btn-dark'}" href="contact.html" style="justify-content:center">Choose ${p.n}</a></div>`).join('');
      document.querySelectorAll('.toggle button').forEach((b) => b.classList.toggle('on', (b.dataset.bill === 'y') === yearly));
    };
    document.querySelector('.toggle').addEventListener('click', (e) => { const b = e.target.closest('[data-bill]'); if (b) { yearly = b.dataset.bill === 'y'; draw(); } });
    draw();
  }

  function bind() {
    const burger = document.getElementById('burger');
    burger.onclick = () => burger.setAttribute('aria-expanded', document.getElementById('pill').classList.toggle('open'));
    const ov = document.getElementById('ov');
    const close = () => ov.classList.remove('on');
    document.getElementById('mx').onclick = close;
    ov.addEventListener('click', (e) => { if (e.target === ov) close(); });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });
    let current = '';
    document.addEventListener('click', (e) => {
      const b = e.target.closest('[data-book]');
      if (!b) return;
      const [n, t] = b.dataset.book.split('|'); current = `${n} at ${t}`;
      document.getElementById('ms').textContent = current; ov.classList.add('on'); document.getElementById('bn').focus();
    });
    document.getElementById('bf').addEventListener('submit', (e) => {
      e.preventDefault();
      if (!validate(e.target)) return toast('Please add your name and a valid email');
      close(); e.target.reset(); toast(`You are booked: ${current}. See you on the mat.`);
    });
    const cf = document.getElementById('cf');
    if (cf) cf.addEventListener('submit', (e) => {
      e.preventDefault();
      const m = document.getElementById('cmsg');
      if (!validate(cf)) { m.textContent = 'Please fill in the highlighted fields.'; return; }
      m.textContent = 'Thank you. We will reply within one working day.'; cf.reset();
    });
  }
  function validate(f) {
    let ok = true;
    f.querySelectorAll('[required]').forEach((i) => {
      const bad = !i.value.trim() || (i.type === 'email' && !/^\S+@\S+\.\S+$/.test(i.value));
      i.classList.toggle('err', bad); if (bad) ok = false;
    });
    return ok;
  }


  /* v2 effects */
  function initFx() {
    const reduce = matchMedia('(prefers-reduced-motion:reduce)').matches;
    const prog = document.createElement('div'); prog.className = 'prog'; document.body.appendChild(prog);
    const hdr = document.querySelector('.hdr'), img = document.querySelector('.media>img');
    let busy = false;
    const onScroll = () => {
      if (busy) return; busy = true;
      requestAnimationFrame(() => {
        const y = window.scrollY, h = document.documentElement.scrollHeight - innerHeight;
        prog.style.width = (h > 0 ? (y / h) * 100 : 0) + '%';
        hdr.classList.toggle('sc', y > 10);
        if (img && !reduce && y < innerHeight * 1.2) img.style.transform = `translateY(${y * 0.08}px) scale(1.12)`;
        busy = false;
      });
    };
    addEventListener('scroll', onScroll, { passive: true }); onScroll();

    document.querySelectorAll('.marq-t').forEach((t) => { t.innerHTML += t.innerHTML; t.parentElement.setAttribute('aria-hidden', 'true'); });

    const nums = document.querySelectorAll('[data-n]');
    if (nums.length && 'IntersectionObserver' in window) {
      const io = new IntersectionObserver((es) => es.forEach((e) => {
        if (!e.isIntersecting) return; io.unobserve(e.target);
        const el = e.target, n = +el.dataset.n, s = el.dataset.s || '', t0 = performance.now();
        const step = (t) => { const k = Math.min(1, (t - t0) / 1400); el.textContent = Math.round(n * (1 - Math.pow(1 - k, 3))) + s; if (k < 1) requestAnimationFrame(step); };
        requestAnimationFrame(step);
      }), { threshold: 0.6 });
      nums.forEach((n) => io.observe(n));
    }

    const sl = document.getElementById('slider');
    if (sl) {
      const by = (d) => sl.scrollBy({ left: d * (sl.firstElementChild.offsetWidth + 20), behavior: 'smooth' });
      document.getElementById('prev').onclick = () => by(-1);
      document.getElementById('next').onclick = () => by(1);
    }

    const orb = document.getElementById('orb');
    if (orb) {
      const lab = document.getElementById('orbLabel'), sec = document.getElementById('orbSec'), btn = document.getElementById('breathBtn');
      const steps = [['Inhale', 4, 1.38], ['Hold', 4, 1.38], ['Exhale', 6, 1]];
      let on = false, i = 0, left = 0, timer;
      const set = () => { const [t, s, sc] = steps[i % 3]; left = s; lab.textContent = t; sec.textContent = left; orb.style.transitionDuration = s + 's'; orb.style.transform = `scale(${sc})`; };
      btn.onclick = () => {
        on = !on;
        if (on) { i = 0; set(); btn.textContent = 'Stop'; timer = setInterval(() => { left--; if (left <= 0) { i++; set(); } else sec.textContent = left; }, 1000); }
        else { clearInterval(timer); btn.textContent = 'Start breathing'; lab.textContent = 'Ready'; sec.textContent = ''; orb.style.transitionDuration = '.8s'; orb.style.transform = 'scale(1)'; }
      };
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    layout(); bind(); initHome(); initClasses(); initPricing(); initFx();
    const tm = document.getElementById('team'); if (tm) team(tm);
  });
})();
