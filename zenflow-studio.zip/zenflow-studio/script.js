/* ===== ZENFLOW STUDIO v3 — script ===== */
(function () {
  'use strict';
  const CUR = '$'; // change to 'Rs. ' for rupees
  const U = (id, w = 900) => `https://images.unsplash.com/photo-${id}?auto=format&fit=crop&w=${w}&q=80`;
  const $ = (s) => document.querySelector(s);

  /* fallback for any image that fails to load */
  const FB = 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 500"><rect width="400" height="500" fill="#d9d5b4"/><text x="200" y="258" text-anchor="middle" font-family="Arial,sans-serif" font-size="28" letter-spacing="5" fill="#7a7330">ZENFLOW</text></svg>');
  document.addEventListener('error', (e) => { const t = e.target; if (t.tagName === 'IMG' && !t.dataset.fb) { t.dataset.fb = 1; t.src = FB; } }, true);

  /* icons */
  const P = {
    leaf: '<path d="M5 19c0-9 6-14 15-14 0 9-5 15-14 15"/><path d="M5 19c3-5 6-8 10-10"/>',
    pin: '<path d="M12 21s7-6 7-11a7 7 0 0 0-14 0c0 5 7 11 7 11z"/><circle cx="12" cy="10" r="2.5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
    phone: '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A15 15 0 0 1 3 6a2 2 0 0 1 2-2z"/>',
    check: '<path d="m5 12 5 5 9-10"/>',
    dash: '<path d="M6 12h12"/>',
    arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
    close: '<path d="M6 6l12 12M18 6 6 18"/>',
    menu: '<path d="M4 8h16M4 16h16"/>',
    heart: '<path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6 7 7M17 17l1.4 1.4M18.4 5.6 17 7M7 17l-1.4 1.4"/>',
    drop: '<path d="M12 3s6 6.5 6 11a6 6 0 0 1-12 0c0-4.5 6-11 6-11z"/>',
    users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 3-6 6.5-6s6.5 2.4 6.5 6M16 5a3.5 3.5 0 0 1 0 7M18 14.5c2.2.7 3.5 2.6 3.5 5.5"/>',
    cal: '<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M4 10h16M8 3v4M16 3v4"/>',
    cup: '<path d="M5 9h12v5a5 5 0 0 1-5 5h-2a5 5 0 0 1-5-5zM17 10h2a2 2 0 0 1 0 4h-2M8 3c0 1.5 1 1.5 1 3M12 3c0 1.5 1 1.5 1 3"/>',
    shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="m9 12 2 2 4-4"/>',
    key: '<circle cx="8" cy="12" r="3.5"/><path d="M11.5 12H21M17 12v3M20 12v2"/>',
    car: '<path d="M4 16v-4l2-5h12l2 5v4zM5 16v2h3v-2M16 16v2h3v-2"/>',
    mat: '<rect x="3" y="9" width="18" height="6" rx="3"/><path d="M15 9v6"/>',
    shirt: '<path d="m8 4-5 3 2 4 3-1v10h8V10l3 1 2-4-5-3a4 4 0 0 1-8 0z"/>'
  };
  const ic = (n) => `<span class="i" aria-hidden="true"><svg viewBox="0 0 24 24">${P[n] || ''}</svg></span>`;

  /* data */
  const T = [
    { n: 'Anaya Sharma', r: 'Vinyasa & breathwork', y: 12, img: '1544005313-94ddf0286df2', b: 'Trained in Rishikesh. Anaya links breath with movement in flowing, energising classes.' },
    { n: 'Daniel Reyes', r: 'Ashtanga & power flow', y: 9, img: '1500648767791-00dcc994a43e', b: 'A former athlete who teaches strong, structured practices with clear, patient cues.' },
    { n: 'Mira Chen', r: 'Yin yoga & meditation', y: 10, img: '1534528741775-53994a69daeb', b: 'Mira holds slow, quiet classes that help the body and mind finally let go.' },
    { n: 'Omar Hassan', r: 'Hatha & mobility', y: 8, img: '1506794778202-cad84cf45f1d', b: 'With a physiotherapy background, Omar is the go-to teacher for stiff backs and hips.' }
  ];
  const C = [
    { n: 'Sunrise Vinyasa', t: '06:30', m: 60, who: 0, lvl: 'All levels', spots: 6, d: [1, 2, 3, 4, 5, 6] },
    { n: 'Gentle Hatha', t: '09:00', m: 60, who: 3, lvl: 'Beginner', spots: 9, d: [1, 3, 5, 0] },
    { n: 'Prenatal Flow', t: '10:30', m: 50, who: 0, lvl: 'Beginner', spots: 4, d: [2, 4, 6] },
    { n: 'Power Ashtanga', t: '12:15', m: 75, who: 1, lvl: 'Advanced', spots: 0, d: [1, 2, 4, 5] },
    { n: 'Mobility Reset', t: '17:30', m: 45, who: 3, lvl: 'All levels', spots: 11, d: [1, 3, 5] },
    { n: 'Yin & Restore', t: '18:45', m: 75, who: 2, lvl: 'All levels', spots: 7, d: [1, 2, 3, 4, 0] },
    { n: 'Breath & Meditation', t: '20:00', m: 40, who: 2, lvl: 'Beginner', spots: 14, d: [2, 4, 6, 0] }
  ];
  const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const PLANS = [
    { n: 'Flow', m: 39, d: 'Four classes a month. A calm start.', f: ['4 classes per month', 'Online class library', 'Mat and prop hire included'] },
    { n: 'Unlimited', m: 89, hot: 1, d: 'Every class, whenever you need it.', f: ['Unlimited studio classes', 'Online class library', 'Bring a friend twice a month', 'Priority booking'] },
    { n: 'Retreat', m: 149, d: 'For a deeper, guided practice.', f: ['Everything in Unlimited', 'Monthly 1:1 private session', 'Weekend workshops included', '10% off retail and retreats'] }
  ];
  const FEAT = [
    ['users', 'Small classes', 'Never more than 14 mats, so teachers can adjust every student.'],
    ['sun', 'Bright, calm studios', 'Natural light, warm wood floors, plants and gently heated rooms.'],
    ['heart', 'Every level welcome', 'Clear options in each class, from first-timers to advanced.'],
    ['mat', 'Everything provided', 'Mats, blocks, straps and bolsters. Just bring yourself.'],
    ['cal', 'Flexible booking', 'Book or cancel up to four hours before class, from your phone.'],
    ['shield', 'Certified teachers', 'Every teacher holds 500+ hour training and keeps learning.']
  ];
  const AMEN = [['drop', 'Showers', 'Hot showers and changing rooms'], ['mat', 'Free mats', 'Mats, props and towels'], ['cup', 'Tea bar', 'Herbal tea after every class'], ['key', 'Lockers', 'Secure, free to use'], ['car', 'Parking', 'Free on-site parking'], ['sun', 'Heated rooms', 'Warm and welcoming year-round'], ['users', 'Step-free', 'Fully accessible studios'], ['heart', 'Retail corner', 'Mats, wear and candles']];
  const JOURNAL = [
    ['1575052814086-f385e2e2ad1b', 'Five stretches for a desk-bound back', '12 Oct 2026 · 5 min read'],
    ['1599901860904-17e6ed7083a0', 'How to start yoga when you feel stiff', '28 Sep 2026 · 6 min read'],
    ['1524863479829-916d8e77f114', 'Yin or Vinyasa: which one suits you?', '9 Sep 2026 · 4 min read']
  ];
  const GAL = ['1552196563-55cd4e45efb3', '1545205597-3d9d02c29597', '1506126613408-eca07ce68773', '1518611012118-696072aa579a', '1593164842264-854604db2260', '1575052814086-f385e2e2ad1b', '1599901860904-17e6ed7083a0'];
  const STYLES = [
    ['Vinyasa Flow', 4, 'Breath-led sequences that build heat, strength and focus.', '1544367567-0f2fcb009e0b'],
    ['Hatha', 2, 'Slower pacing with held poses. Ideal for learning the basics.', '1545205597-3d9d02c29597'],
    ['Ashtanga', 5, 'A set, athletic sequence for experienced practitioners.', '1593164842264-854604db2260'],
    ['Yin Yoga', 1, 'Long, passive holds that release deep tension in hips and back.', '1506126613408-eca07ce68773'],
    ['Prenatal', 2, 'Safe, supportive movement for every trimester.', '1599901860904-17e6ed7083a0'],
    ['Meditation', 1, 'Guided breathing and stillness to settle a busy mind.', '1524863479829-916d8e77f114']
  ];

  const time12 = (t) => { const [h, m] = t.split(':').map(Number); return `${((h + 11) % 12) + 1}:${String(m).padStart(2, '0')} ${h < 12 ? 'AM' : 'PM'}`; };
  const classesOn = (d) => C.filter((c) => c.d.includes(d)).sort((a, b) => a.t.localeCompare(b.t));

  /* layout */
  const page = document.body.dataset.page;
  const nav = [['index.html', 'Home', 'home'], ['classes.html', 'Classes', 'classes'], ['pricing.html', 'Pricing', 'pricing'], ['about.html', 'About', 'about'], ['contact.html', 'Contact', 'contact']];
  function layout() {
    document.body.insertAdjacentHTML('afterbegin', `
      <div class="announce">First class free for new members. Use code <b>ZEN35</b> for 35% off your first month.<a href="pricing.html">See offers</a></div>
      <header class="hdr"><div class="wrap hdr-in">
        <a class="logo" href="index.html"><b>${ic('leaf')}</b>ZENFLOW</a>
        <nav class="pill" id="pill" aria-label="Main">${nav.map((n) => `<a href="${n[0]}" class="${n[2] === page ? 'on' : ''}">${n[1]}</a>`).join('')}</nav>
        <div class="hdr-r"><a class="btn btn-dark" href="classes.html">Book a class</a><button class="burger" id="burger" aria-label="Menu" aria-expanded="false">${ic('menu')}</button></div>
      </div></header>`);
    document.body.insertAdjacentHTML('beforeend', `
      <footer class="ftr"><div class="wrap">
        <div class="ftr-top"><h3>Stay in the flow</h3>
          <div><form class="nf" id="nf" novalidate><input type="email" placeholder="Your email address" aria-label="Email address"><button class="btn btn-light" type="submit">Subscribe</button></form></div></div>
        <div class="ftr-g">
          <div><a class="logo" href="index.html"><b>${ic('leaf')}</b>ZENFLOW STUDIO</a><p style="max-width:24em">A modern yoga and wellness studio with calming spaces, expert teachers and classes for every body.</p>
            <div class="soc"><a href="#" aria-label="Instagram">Ig</a><a href="#" aria-label="Facebook">Fb</a><a href="#" aria-label="YouTube">Yt</a></div></div>
          <div><h4>Studio</h4><ul><li><a href="classes.html">Class schedule</a></li><li><a href="pricing.html">Memberships</a></li><li><a href="about.html">Our teachers</a></li><li><a href="contact.html">Private sessions</a></li></ul></div>
          <div><h4>Visit</h4><ul><li>24 Willow Lane, Karachi</li><li>Mon–Sat 6am – 9pm</li><li>Sun 8am – 6pm</li></ul></div>
          <div><h4>Contact</h4><ul><li><a href="contact.html">hello@zenflow.studio</a></li><li>+92 300 000 0000</li><li><a href="contact.html">Send a message</a></li></ul></div>
        </div>
        <div class="ftr-b"><span>© ${new Date().getFullYear()} Zenflow Studio. All rights reserved.</span><span>Breathe in. Move on.</span></div>
        <div class="mark" aria-hidden="true">ZENFLOW</div>
      </div></footer>
      <div class="ov" id="ov"><div class="modal" role="dialog" aria-modal="true" aria-labelledby="mt">
        <button class="x" id="mx" aria-label="Close">${ic('close')}</button>
        <h3 id="mt">Reserve your spot</h3><p id="ms" style="color:var(--mut)"></p>
        <form class="form" id="bf" style="border:0;padding:0;background:none" novalidate>
          <label for="bn">Full name</label><input id="bn" required placeholder="Your name">
          <label for="be">Email</label><input id="be" type="email" required placeholder="you@example.com">
          <button class="btn btn-dark" type="submit" style="width:100%">Confirm booking</button>
        </form></div></div>
      <div class="toast" id="toast" role="status"></div>`);
    document.querySelectorAll('[data-u]').forEach((im) => { im.src = U(im.dataset.u, im.dataset.w || 900); });
  }
  const paint = () => document.querySelectorAll('[data-i]').forEach((el) => { if (!el.dataset.d) { el.innerHTML = ic(el.dataset.i); el.dataset.d = 1; } });

  let tt;
  const toast = (m) => { const t = $('#toast'); t.textContent = m; t.classList.add('on'); clearTimeout(tt); tt = setTimeout(() => t.classList.remove('on'), 2800); };

  /* renderers */
  const row = (c) => `<div class="row-c">
    <div class="t">${time12(c.t)}</div>
    <div><h3>${c.n}</h3><small>with ${T[c.who].n}</small></div>
    <div class="lvl">${c.lvl}</div><div class="dur">${c.m} min</div>
    <div class="spots ${c.spots ? '' : 'full'}">${c.spots ? c.spots + ' spots left' : 'Class full'}</div>
    <button class="btn btn-dark btn-sm" data-book="${c.n}|${time12(c.t)}">${c.spots ? 'Book' : 'Join waitlist'}</button></div>`;
  const put = (sel, html) => { const el = $(sel); if (el) el.innerHTML = html; };

  function renderStatic() {
    put('#team', T.map((t) => `<div class="tm"><img src="${U(t.img, 700)}" alt="${t.n}" loading="lazy"><h3>${t.n}</h3><div class="rl">${t.r}</div><p>${t.b}</p><span class="yrs">${t.y} years teaching</span></div>`).join(''));
    put('#feat', FEAT.map((f) => `<div class="fc">${ic(f[0])}<h3>${f[1]}</h3><p>${f[2]}</p></div>`).join(''));
    put('#amen', AMEN.map((f) => `<div class="fc">${ic(f[0])}<h3>${f[1]}</h3><p>${f[2]}</p></div>`).join(''));
    put('#journal', JOURNAL.map((j) => `<a class="jn" href="classes.html"><div class="im"><img src="${U(j[0], 800)}" alt="" loading="lazy"></div><small>${j[2]}</small><h3>${j[1]}</h3></a>`).join(''));
    put('#gallery', GAL.map((g) => `<div><img src="${U(g, 800)}" alt="Inside Zenflow Studio" loading="lazy"></div>`).join(''));
    put('#styles', STYLES.map((s) => `<div class="st"><img src="${U(s[3], 800)}" alt="" loading="lazy"><h3>${s[0]}</h3><p>${s[2]}</p><div class="dots">Intensity ${[1, 2, 3, 4, 5].map((n) => `<i class="${n <= s[1] ? 'on' : ''}"></i>`).join('')}</div></div>`).join(''));
    const td = $('#today');
    if (td) {
      const d = new Date().getDay(); $('#todayName').textContent = DAYS[d];
      td.innerHTML = classesOn(d).slice(0, 4).map(row).join('') || '<p style="padding:2rem 0">No classes today. See the full schedule.</p>';
    }
    const cd = $('#countdown');
    if (cd) {
      const tick = () => { const n = new Date(), s = Math.max(0, new Date(n.getFullYear(), n.getMonth() + 1, 1) - n) / 1000; cd.textContent = `${Math.floor(s / 86400)}d ${Math.floor(s % 86400 / 3600)}h ${Math.floor(s % 3600 / 60)}m`; };
      tick(); setInterval(tick, 30000);
    }
  }

  function initClasses() {
    const list = $('#list'); if (!list) return;
    let day = new Date().getDay(), lvl = 'All', who = 'All';
    $('#tch').innerHTML = '<option>All</option>' + T.map((t, i) => `<option value="${i}">${t.n}</option>`).join('');
    const draw = () => {
      $('#days').innerHTML = [1, 2, 3, 4, 5, 6, 0].map((d) => `<button class="day ${d === day ? 'on' : ''}" data-day="${d}">${DAYS[d].slice(0, 3)}</button>`).join('');
      const items = classesOn(day).filter((c) => (lvl === 'All' || c.lvl === lvl) && (who === 'All' || c.who === +who));
      list.innerHTML = items.length ? items.map(row).join('') : '<p style="padding:2.5rem 0;color:var(--mut)">No classes match. Try another day, level or teacher.</p>';
    };
    $('#days').addEventListener('click', (e) => { const b = e.target.closest('[data-day]'); if (b) { day = +b.dataset.day; draw(); } });
    $('#lvl').addEventListener('change', (e) => { lvl = e.target.value; draw(); });
    $('#tch').addEventListener('change', (e) => { who = e.target.value; draw(); });
    draw();
  }

  function initPlans() {
    const box = $('#plans'); if (!box) return;
    let yearly = false;
    const draw = () => {
      box.innerHTML = PLANS.map((p) => `<div class="plan ${p.hot ? 'hot' : ''}">${p.hot ? '<span class="pop">Most popular</span>' : ''}<h3>${p.n}</h3><div class="pr">${CUR}${yearly ? Math.round(p.m * 0.8) : p.m}<small> /month</small></div><p>${p.d}</p>
        <ul>${p.f.map((f) => `<li>${ic('check')}${f}</li>`).join('')}</ul>
        <a class="btn ${p.hot ? 'btn-light' : 'btn-dark'}" href="contact.html">Choose ${p.n}</a></div>`).join('');
      document.querySelectorAll('.toggle button').forEach((b) => b.classList.toggle('on', (b.dataset.bill === 'y') === yearly));
    };
    const tg = $('.toggle');
    if (tg) tg.addEventListener('click', (e) => { const b = e.target.closest('[data-bill]'); if (b) { yearly = b.dataset.bill === 'y'; draw(); } });
    draw();
  }

  function validate(f) {
    let ok = true;
    f.querySelectorAll('[required]').forEach((i) => {
      const bad = !i.value.trim() || (i.type === 'email' && !/^\S+@\S+\.\S+$/.test(i.value));
      i.classList.toggle('err', bad); if (bad) ok = false;
    });
    return ok;
  }

  function bind() {
    const burger = $('#burger');
    burger.onclick = () => burger.setAttribute('aria-expanded', $('#pill').classList.toggle('open'));
    const ov = $('#ov'), close = () => ov.classList.remove('on');
    $('#mx').onclick = close;
    ov.addEventListener('click', (e) => { if (e.target === ov) close(); });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });
    let current = '';
    document.addEventListener('click', (e) => {
      const b = e.target.closest('[data-book]'); if (!b) return;
      const [n, t] = b.dataset.book.split('|'); current = `${n} at ${t}`;
      $('#ms').textContent = current; ov.classList.add('on'); $('#bn').focus();
    });
    $('#bf').addEventListener('submit', (e) => {
      e.preventDefault();
      if (!validate(e.target)) return toast('Please add your name and a valid email');
      close(); e.target.reset(); toast(`You are booked: ${current}. See you on the mat.`);
    });
    $('#nf').addEventListener('submit', (e) => {
      e.preventDefault();
      const v = e.target.querySelector('input').value.trim();
      if (!/^\S+@\S+\.\S+$/.test(v)) return toast('Please enter a valid email address');
      e.target.reset(); toast('You are subscribed. Welcome to the flow.');
    });
    const cf = $('#cf');
    if (cf) cf.addEventListener('submit', (e) => {
      e.preventDefault();
      const m = $('#cmsg');
      if (!validate(cf)) { m.textContent = 'Please fill in the highlighted fields.'; return; }
      m.textContent = 'Thank you. We will reply within one working day.'; cf.reset();
    });
  }

  function initFx() {
    const reduce = matchMedia('(prefers-reduced-motion:reduce)').matches;
    const prog = document.createElement('div'); prog.className = 'prog'; document.body.appendChild(prog);
    const hdr = $('.hdr'), img = $('.media>img');
    let busy = false;
    const onScroll = () => {
      if (busy) return; busy = true;
      requestAnimationFrame(() => {
        const y = window.scrollY, h = document.documentElement.scrollHeight - innerHeight;
        prog.style.width = (h > 0 ? (y / h) * 100 : 0) + '%';
        hdr.classList.toggle('sc', y > 10);
        if (img && !reduce && y < innerHeight * 1.2) img.style.transform = `translateY(${y * 0.07}px) scale(1.1)`;
        busy = false;
      });
    };
    addEventListener('scroll', onScroll, { passive: true }); onScroll();

    document.querySelectorAll('.marq-t').forEach((t) => { t.innerHTML += t.innerHTML; t.parentElement.setAttribute('aria-hidden', 'true'); });

    const nums = document.querySelectorAll('[data-n]');
    if (nums.length && 'IntersectionObserver' in window) {
      const io = new IntersectionObserver((es) => es.forEach((e) => {
        if (!e.isIntersecting) return; io.unobserve(e.target);
        const el = e.target, n = +el.dataset.n, s = el.dataset.s || '', t0 = performance.now();
        const step = (t) => { const k = Math.min(1, (t - t0) / 1400); el.textContent = Math.round(n * (1 - Math.pow(1 - k, 3))) + s; if (k < 1) requestAnimationFrame(step); };
        requestAnimationFrame(step);
      }), { threshold: 0.6 });
      nums.forEach((n) => io.observe(n));
    }

    const sl = $('#slider');
    if (sl) {
      const by = (d) => sl.scrollBy({ left: d * (sl.firstElementChild.offsetWidth + 20), behavior: 'smooth' });
      $('#prev').onclick = () => by(-1); $('#next').onclick = () => by(1);
    }

    const orb = $('#orb');
    if (orb) {
      const lab = $('#orbLabel'), sec = $('#orbSec'), btn = $('#breathBtn');
      const steps = [['Inhale', 4, 1.38], ['Hold', 4, 1.38], ['Exhale', 6, 1]];
      let on = false, i = 0, left = 0, timer;
      const set = () => { const [t, s, sc] = steps[i % 3]; left = s; lab.textContent = t; sec.textContent = left; orb.style.transitionDuration = s + 's'; orb.style.transform = `scale(${sc})`; };
      btn.onclick = () => {
        on = !on;
        if (on) { i = 0; set(); btn.textContent = 'Stop'; timer = setInterval(() => { left--; if (left <= 0) { i++; set(); } else sec.textContent = left; }, 1000); }
        else { clearInterval(timer); btn.textContent = 'Start breathing'; lab.textContent = 'Ready'; sec.textContent = ''; orb.style.transitionDuration = '.8s'; orb.style.transform = 'scale(1)'; }
      };
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    layout(); renderStatic(); initClasses(); initPlans(); bind(); paint(); initFx();
  });
})();
